﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace snake
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Bodypart[] Body = new Bodypart[200];
        Bodypart Head;
        Apple apple = new Apple();
        int Last;
        int High = 0;
        DispatcherTimer pause = new DispatcherTimer();
        Key way;
        Key preway;
        bool first = true;
        List<Label> StartMenu = new List<Label>();
        List<Label> Loose = new List<Label>();
        List<Label> VicMessage = new List<Label>();
        bool Death = false;
        bool IsGenerated = false;
        
        public class Bodypart : Label
        {
            public void Make()
            {
                this.Width = 30;
                this.Height = 30;
                this.BorderThickness = new Thickness(3, 3, 3, 3);
                this.BorderBrush = new SolidColorBrush(Colors.Black);
                this.Background = new SolidColorBrush(Color.FromRgb(48, 255, 2));
            }
        }
        public class Apple : Label
        {
            public void Make()
            {
                this.Width = 30;
                this.Height = 30;
                this.BorderThickness = new Thickness(3, 3, 3, 3);
                this.BorderBrush = new SolidColorBrush(Colors.Black);
                this.Background = new SolidColorBrush(Colors.Red);
            }
        }
        public Bodypart Addbody( double x, double y)
        {
            var a = new Bodypart();
            a.Make();
            Field.Children.Add(a);
            Canvas.SetLeft(a, x);
            Canvas.SetTop(a, y);
            return a;
        }
        public void Move()
        {
            for (int i = Last; i > 0; i--)
            {
                double x = Canvas.GetLeft(Body[i-1]);
                double y = Canvas.GetTop(Body[i-1]);
                Canvas.SetLeft(Body[i], x);
                Canvas.SetTop(Body[i],y);
            }
        }
        public void Eat()
        {
            Generate();
            var a = Addbody(Canvas.GetLeft(Head), Canvas.GetTop(Head));
            Last++;
            Score.Content = Last+1;
            if (Last+1 > High)
            {
                High = Last+1;
                Highscore.Content = High;
            }
            Body[Last] = a;
            IsGenerated = true;
        }

        private void Window_KeyDown(object sender, KeyEventArgs e)
        {
            if (first)
            {
                first = false;
                foreach (var a in StartMenu) a.Visibility = Visibility.Hidden;
                Head.Visibility = Visibility.Visible;
                apple.Visibility = Visibility.Visible;
                pause.Start();
                HeadMove();
            }
            preway = way;
            if ((e.Key == Key.Up && preway != Key.Down && preway != Key.S) || (e.Key == Key.Down && preway != Key.Up && preway != Key.W) || (e.Key == Key.Left && preway != Key.Right && preway != Key.D) || (e.Key == Key.Right && preway != Key.Left && preway != Key.A) || (e.Key == Key.W && preway != Key.S && preway != Key.Down) || (e.Key == Key.A && preway != Key.D && preway != Key.Right) || (e.Key == Key.S && preway != Key.W && preway != Key.Up) || (e.Key == Key.D && preway != Key.A && preway != Key.Left))
                way = e.Key;
        }
        private void Pause_Tick(object sender, EventArgs e)
        {
            Move();
            HeadMove();
            if (Canvas.GetLeft(Head) == Canvas.GetLeft(apple) && Canvas.GetTop(Head) == Canvas.GetTop(apple)) Eat();
            if (!IsGenerated)
                for (int i = 4; i <= Last; i++)
                    if (Canvas.GetLeft(Head) == Canvas.GetLeft(Body[i]) && Canvas.GetTop(Head) == Canvas.GetTop(Body[i])) Death = true;
                    else;
            else for (int j = 4; j < Last; j++)
                 if (Canvas.GetLeft(Head) == Canvas.GetLeft(Body[j]) && Canvas.GetTop(Head) == Canvas.GetTop(Body[j])) { Death = true; IsGenerated = false; }
            if (Death) GameOver();
            if (Last == 199) Victory();
        }
        private void HeadMove()
        {
            double x = Canvas.GetLeft(Head);
            double y = Canvas.GetTop(Head);
            if (way==Key.Up||way==Key.W)
            {
                if (y == 10) Canvas.SetTop(Head, 370);
                else Canvas.SetTop(Head, y-40);
            }
            else if (way == Key.Down || way == Key.S)
            {
                if (y == 370) Canvas.SetTop(Head, 10);
                else Canvas.SetTop(Head, y+40);
            }
            else if (way == Key.Left || way == Key.A)
            {
                if (x == 10) Canvas.SetLeft(Head, 770);
                else Canvas.SetLeft(Head, x-40);
            }
            else if (way == Key.Right || way == Key.D)
            {
                if (x == 770) Canvas.SetLeft(Head, 10);
                else Canvas.SetLeft(Head, x+40);
            }
        }
        private void Generate()
        {
            Random rnd = new Random();
            bool NotOnBody = true;
            int x;
            int y;
            do
            {
                x = rnd.Next(0, 19) * 40 + 10;
                y = rnd.Next(0, 9) * 40 + 10;
                for (int i = 0; i <= Last; i++)
                    if (x == Canvas.GetLeft(Body[i]) && y == Canvas.GetTop(Body[i])) NotOnBody = false;
            }
            while (!NotOnBody);
            Canvas.SetLeft(apple, x);
            Canvas.SetTop(apple, y);
        }
        public void GameOver()
        {
            Head.Visibility = Visibility.Hidden;
            apple.Visibility = Visibility.Hidden;
            for (int i = 1; i <= Last; i++)
                Field.Children.Remove(Body[i]);
            Array.Clear(Body, 1, Last);
            FinalScore.Content = Last + 1;
            foreach (var a in Loose) a.Visibility = Visibility.Visible;
            Restart.IsEnabled = true;
            pause.Stop();
        }
        public MainWindow()
        {
            InitializeComponent();
            Head = Addbody(410, 210);
            Body[0] = Head;
            Last = 0;
            pause.Tick += new EventHandler(Pause_Tick);
            pause.Interval = new TimeSpan(1400000);
            Field.Children.Add(apple);
            apple.Make();
            Generate();
            Head.Visibility = Visibility.Hidden;
            apple.Visibility = Visibility.Hidden;
            StartMenu.Add(title1);
            StartMenu.Add(title2);
            StartMenu.Add(butw);
            StartMenu.Add(buta);
            StartMenu.Add(buts);
            StartMenu.Add(butd);
            StartMenu.Add(butup);
            StartMenu.Add(butdown);
            StartMenu.Add(butleft);
            StartMenu.Add(butright);
            Loose.Add(title3);
            Loose.Add(title4);
            Loose.Add(FinalScore);
            Loose.Add(Restart);
            VicMessage.Add(title5);
            VicMessage.Add(title6);
            VicMessage.Add(Restart2);
        }

        private void Restart_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            Restart.IsEnabled = false;
            Restart2.IsEnabled = false;
            foreach (var a in Loose) a.Visibility = Visibility.Hidden;
            foreach (var a in VicMessage) a.Visibility = Visibility.Hidden;
            foreach (var a in StartMenu) a.Visibility = Visibility.Visible;
            Canvas.SetLeft(Head, 410);
            Canvas.SetTop(Head, 210);
            Last = 0;
            Generate();
            first = true;
            way = Key.U;
            Score.Content = "1";
            Death = false;
        }
        public void Victory()
        {
            Head.Visibility = Visibility.Hidden;
            apple.Visibility = Visibility.Hidden;
            for (int i = 1; i <= Last; i++)
                Field.Children.Remove(Body[i]);
            Array.Clear(Body, 1, Last);
            foreach (var a in VicMessage) a.Visibility = Visibility.Visible;
            Restart2.IsEnabled = true;
            pause.Stop();
        }
    }
}
